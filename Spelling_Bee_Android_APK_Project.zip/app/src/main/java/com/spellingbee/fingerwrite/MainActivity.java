package com.spellingbee.fingerwrite;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingWord = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(Locale.US);
                tts.setSpeechRate(0.90f);
                ttsReady = (res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED);
                if (ttsReady && pendingWord != null) {
                    tts.speak(pendingWord, TextToSpeech.QUEUE_FLUSH, null, "sb_word");
                    pendingWord = null;
                }
            }
        });

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void speak(String word) {
                if (word == null || word.isEmpty()) return;
                if (ttsReady && tts != null) {
                    tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "sb_word");
                } else {
                    pendingWord = word;
                }
            }
        }, "AndroidTTS");

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/www/index.html");
        setContentView(webView);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
